<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy;2020 <div class="bullet"></div> Tool Management System <div class="bullet"></div> <a href="https://getstisla.com/" target="_blank">Stisla</a> template
    </div>
    <div class="footer-right">
        2.3.0
    </div>
</footer>

</div>
</div>


</body>

</html>